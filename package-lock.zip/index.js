const express = require("express");
require("dotenv").config();
const morgan = require("morgan");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const app = express();

const connectDB = require("./config/dbConfig");
const userRouter = require("./routes/userRoute");

connectDB();

const port = process.env.PORT;

app.use(morgan("dev"));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/user", userRouter);

app.use(cors());
app.use(cookieParser());

app.get("/", (req, res) => {
  return res.status(200).send("<h1>Welcome To Node Server</h1>");
});

app.listen(port, () => {
  console.log(`mongodb is connected on server :${port}`);
});
