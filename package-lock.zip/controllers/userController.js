const userModel = require("../models/userModel");

exports.register = async (req, res, next) => {
  try {
    const { name, email, password, address, city, country, phone } = req.body;
    if (!email || !password || !name || !address || !city || !country || !phone)
      return res.status(401).json({ message: "please enter all field" });

    const userExist = await userModel.findOne({ email });

    if (userExist)
      return res.status(401).json({ message: "user Already Exist" });

    const user = await userModel.create({
      name,
      email,
      password,
      address,
      city,
      country,
      phone,
    });

    res.status(201).json({
      data: user,
      message: `${user.name} your account is successfully created`,
    });
  } catch (error) {
    res.status(500).json({
      message: "Internal server error",
      error,
    });
  }
};

exports.login = async (req, res, next) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(401).json({ message: "please enter all field" });

  const userExist = await userModel.findOne({ email });
  if (!userExist)
    return res.status(401).json({
      message:
        "your account is not register our site please register your account and then login",
    });
};
